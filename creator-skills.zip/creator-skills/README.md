# Creator Skills for Claude Code 🎬

A small bundle of Claude Code **skills** for making YouTube videos & Shorts, images,
scripts, and audio/voiceover. Shared by a friend. Two skills inside:

- **higgsfield-shorts-pipeline** — end-to-end video production: script → AI clips →
  voiceover → assembly → thumbnail + SRT + YouTube metadata, with all the credit-saving
  tool workarounds baked in.
- **video-to-skill** — watch any tutorial video and turn its method into a new permanent
  Claude skill (learn a workflow without buying the creator's paid pack).

---

## 1. Install the skills (2 minutes)

You're on **Claude Code** (CLI / desktop / IDE) on a Mac. Skills live in `~/.claude/skills/`.
Copy the two skill folders there:

```bash
# from wherever you unzipped this bundle:
mkdir -p ~/.claude/skills
cp -R higgsfield-shorts-pipeline video-to-skill ~/.claude/skills/
```

Then **start a new Claude Code session** — skills load at session start, so they'll be
available next time, not the current session. Ask Claude "what skills do I have?" to confirm.

> ⚠️ These are Claude **Code** skills. They do NOT apply to the claude.ai website — you need
> the Claude Code app / CLI for `~/.claude/skills/` to mean anything.

## 2. Connect what the skills actually run on

The skills are the "how." The video/image/audio **generation engine** is a separate thing you
connect with your **own account** (it spends your credits, not the sharer's):

| You need | What it powers | How to add it |
|---|---|---|
| **Higgsfield MCP connector** (required for higgsfield-shorts-pipeline) | `generate_image` / `generate_video` / `generate_audio`, `explainer_video`, `nano_banana_pro`, `shorts_studio`, `list_voices`, `show_generations`, thumbnails | In Claude Code run **`/mcp`** (or `claude mcp add`) and add the Higgsfield connector, then sign in with **your own Higgsfield account** (you'll need credits). |
| **yt-dlp** (helps video-to-skill) | Pulling a YouTube video's transcript/subtitles for analysis | `brew install yt-dlp` on your Mac. |

Optional extras (nice for scripts, not required):
- Enable the **marketing** plugin for `content-creation` / `draft-content` (script & caption
  writing craft). In Claude Code: `/plugin` → add the marketing plugin from the marketplace.
- Enable the **anthropic-skills** plugin for `reference-video-adaptation`, `canvas-design`, and
  other creator tools.

## 3. First test

Open Claude Code and say: *"Make me a 45-second YouTube Short about [topic]."* If the Higgsfield
connector is linked, the pipeline skill takes over — it'll script it in blocks, generate the
voiceover and clips on your account, assemble the MP4, and hand back the video + SRT + thumbnail
+ copy-paste YouTube title/description. Start with ONE short to see your credit cost before
going big.

---

*Nothing here contains anyone's account credentials or private data — just the reusable workflow.
The generation runs entirely on your own Higgsfield account.*
