# Creator Skills for Claude Code 🎬

A small bundle of Claude Code **skills** for making YouTube videos & Shorts — scripting,
images, voiceover, assembly, thumbnails, and SEO. Shared by a friend. **Three skills inside:**

- **higgsfield-shorts-pipeline** — end-to-end video production: full pre-production treatment
  for your approval → AI clips → voiceover → assembly → thumbnail + SRT + YouTube metadata,
  with all the credit-saving tool workarounds baked in. Includes a **free local render path**
  (ffmpeg) that makes illustration/sketch Shorts for ~5 credits instead of ~210.
- **reference-video-adaptation** — point it at a YouTube video/channel you admire; it reverse-
  engineers *why* it works and rewrites that format for your own niche as a ready-to-produce
  script package. (Great for "make one like this, but about money.")
- **video-to-skill** — watch any tutorial video and turn its method into a new permanent
  Claude skill (learn a workflow without buying the creator's paid pack).

---

## 1. Install the skills (2 minutes)

You're on **Claude Code** (CLI / desktop / IDE) on a Mac. Skills live in `~/.claude/skills/`.
Copy the three skill folders there:

```bash
# from wherever you unzipped this bundle:
mkdir -p ~/.claude/skills
cp -R higgsfield-shorts-pipeline reference-video-adaptation video-to-skill ~/.claude/skills/
```

Then **start a new Claude Code session** — skills load at session start, so they'll be
available next time, not the current session. Ask Claude "what skills do I have?" to confirm.

> ⚠️ These are Claude **Code** skills. They do NOT apply to the claude.ai website — you need
> the Claude Code app / CLI for `~/.claude/skills/` to mean anything.

## 2. Connect what the skills actually run on

The skills are the "how." The video/image/audio **generation engine** is a separate thing you
connect with your **own account** (it spends your credits, not the sharer's):

| You need | What it powers | How to add it |
|---|---|---|
| **Higgsfield MCP connector** ⭐ *required* | `generate_image` / `generate_video` / `generate_audio`, `explainer_video`, `nano_banana_pro`, `list_voices`, `show_generations`, thumbnails | In Claude Code run **`/mcp`** (or `claude mcp add`) and add the Higgsfield connector, then sign in with **your own Higgsfield account** (you'll need credits). |
| **ffmpeg** *(recommended — unlocks the free render path)* | The local Ken Burns render in `higgsfield-shorts-pipeline/scripts/build.sh` — makes sketch/illustration Shorts for ~5 cr instead of ~210 | `brew install ffmpeg` in your Mac Terminal (installs Homebrew first if you don't have it: see brew.sh). |
| **yt-dlp** *(helps video-to-skill & reference analysis)* | Pulling a YouTube video's transcript/subtitles for analysis | `brew install yt-dlp` |

Optional extra (nice for scripts, not required):
- Enable the **marketing** plugin for `content-creation` / `draft-content` (script & caption
  writing craft). In Claude Code: `/plugin` → add the marketing plugin from the marketplace.

## 3. First test

Open Claude Code and say: *"Make me a 45-second YouTube Short about [your topic]."* If the
Higgsfield connector is linked, the pipeline skill takes over — it will FIRST show you a full
treatment (script in blocks, per-scene image prompts, voice plan, thumbnail, and copy-paste
YouTube title/description/tags + estimated credit cost) for your approval, THEN generate the
voiceover and clips on your account, assemble the MP4, and hand back the video + SRT + thumbnail.
Start with ONE short to see your credit cost before going big.

To model a video you like: *"Here's a YouTube link — make one like this but about [your niche]."*
That triggers `reference-video-adaptation`, which breaks the reference down and rewrites its
format for your topic.

---

*Nothing here contains anyone's account credentials or private data — just the reusable workflow.
The generation runs entirely on your own Higgsfield account.*
