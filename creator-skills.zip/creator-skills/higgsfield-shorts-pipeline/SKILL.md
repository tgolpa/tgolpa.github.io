---
name: higgsfield-shorts-pipeline
description: End-to-end YouTube video production pipeline using Higgsfield MCP tools. ALWAYS use this skill whenever the user asks to make, script, voice, assemble, fix, or regenerate a YouTube Short or long-form video, mentions Higgsfield, seedance, explainer_video, nano_banana_pro, voiceover/narration generation, subtitles/SRT, or thumbnails — even if they don't say "pipeline." First presents a full pre-production treatment for approval — script, per-scene image prompts, per-block audio/voice, thumbnail, and copy-paste YouTube title/description/tags — THEN generates. Encodes critical tool workarounds, voice settings, assembly ordering, and delivery-package standards that prevent wasted credits and broken output.
---

# Higgsfield Shorts Production Pipeline

A credit-efficient workflow for producing YouTube Shorts and long-form videos via the Higgsfield MCP connector. Follow this exactly — every rule below was learned by burning credits on the alternative.

> **Setup (one-time):** this skill drives the **Higgsfield MCP connector**, which you add to Claude Code yourself and sign into with your **own Higgsfield account** (video/image/audio generation spends *your* credits). See the bundle README for how to connect it. The skill is the "how"; your Higgsfield account is the engine.

Working style: fast execution, minimal back-and-forth, production-ready deliverables. Default to acting; ask only when a choice genuinely changes cost or output.

## Step 0 — Pre-production treatment (ALWAYS present this for approval BEFORE generating anything)

Generation costs credits; planning is free. Before submitting a single `generate_*` job, chart the ENTIRE video as one treatment and show it to the user for a yes/edits. This is the most important habit — it catches problems while they are free to fix. Deliver the whole thing in one message:

- **Concept & hook** — the one-line premise + the exact first-2-seconds hook line.
- **Full narration script**, split into the numbered fixed-length blocks you will actually voice (obey the pacing/word-count rules below). Each block = the verbatim narration text.
- **Per-block shot list** — a table with ONE ROW PER BLOCK, columns:
  - **Image/scene prompt** — the exact `nano_banana_pro` / `generate_video` prompt (subject, composition, lighting, camera, style, negatives) that makes that clip.
  - **Audio** — that block's narration line + any ambient/SFX note, plus the **voice preset** + `speech_rate` it uses.
  - **On-screen** — any text/emphasis (usually none baked in; note it for thumbnail/SRT).
- **Character/style reference plan** — the one reference image to generate first and reuse everywhere.
- **Thumbnail** — image prompt + the bold curiosity-gap text overlay.
- **YouTube metadata** — proposed title (emoji if fitting), description, tags/hashtags, and chapters for long-form — all copy-paste ready.
- **Estimated credit cost** + the generation order.

Present it clean and skimmable (numbered blocks + the shot-list table). Only after the user approves or edits do you run the generation steps below. If they say "just make it," STILL show the treatment first, then proceed unless they flag a change — the point is they SEE the full package before credits burn, not that they must reply.

## Pipeline overview (standard order)

0. **Present the Step 0 treatment for approval** (script + per-scene image prompts + per-block audio + thumbnail + metadata + cost) — never skip this
1. **Script** the video in fixed-length blocks (see Script rules)
2. **Character/style reference** via `nano_banana_pro` (if characters or consistent style needed)
3. **Submit ALL audio first** via `generate_audio` (fastest to complete)
4. **Submit video clips** via `generate_video` (seedance_2_0, fast mode, 720p)
5. **Verify completion** via `show_generations` — the ONLY way to check job status (no polling tool exists)
6. **Assemble** via `explainer_video` only after every job shows completed
7. **Deliver package**: final MP4 link + SRT + thumbnail + copy-paste metadata

## Critical tool behaviors (non-negotiable)

- **seedance calls**: include the `declined_preset_id` workaround on EVERY call (known offending presets: `24bae836...` and `cb116576...`). Without it, unwanted presets attach.
- **`explainer_video`**: submitting with pending job IDs returns **404** (it does not queue). All audio + video jobs must show completed in `show_generations` first (`type: video`, `size: 8` to confirm clips).
- **`explainer_video` does NOT accept a background music parameter.** Don't attempt it.
- **NEVER use `reframe`** — it costs more than regenerating the clip fresh. Regenerate instead.
- **`nano_banana_pro` NSFW filter false-positives on death imagery** (skulls, plague, corpses, executions). Reword prompts euphemistically ("fallen figure," "still form," historical framing) rather than fighting the filter.
- **Rate limit**: ~6 concurrent seedance jobs. On 429, wait and retry remaining jobs in batches.
- **Assembly is free**; re-running caption transcription costs ~0.30 credits. Regenerating a single clip + reassembling is the cheap fix path — never redo the whole video for one bad block.
- **Gemini Omni** requires a paid Higgsfield plan (403 on free tier). Kling 3.0 Turbo is the text-to-video fallback but does not accept image references the same way. Style key images from `nano_banana_pro` pass to Gemini Omni clips via `role: image` in the `medias` array using the job ID.

## Video specs

- **Shorts**: 9:16 vertical, `width: 720, height: 1280`, seedance_2_0 fast mode, 720p
- **Long-form**: 16:9, `width: 1280, height: 720`
- Blocks: typically 10s or 15s windows; total Short runtime ~40–60s
- Photorealistic unless the channel style says otherwise; ambient audio off (narration laid over at assembly); no on-screen text baked into clips

## Voice settings

Higgsfield ships stock preset voices. Pick one per channel and stay consistent. **Always confirm the exact `voice_id` UUID via `list_voices` in your own account before submitting — do not guess IDs.** `generate_audio` uses `voice_type: preset` with the UUID `voice_id`.

Example pairing pattern (choose voices that fit your niche):
| Role | Example voice | Settings |
|---|---|---|
| Default narrator (deep male documentary) | e.g. "Arthur" / "Sterling" | `speech_rate: -10` |
| First-person female narration | e.g. "Roxie" | default rate |

### Audio truncation fix (standard on ALL final blocks)

Final narration blocks get clipped at the block boundary. Standard fix, apply every time:
- Final block uses `speech_rate: -5` (not -10)
- Place the critical phrase **mid-sentence**, ending with a disposable tail word
- Target ~7 seconds of speech in a 10-second window

### Pacing rules (all blocks)

- Uniform take lengths across blocks — inconsistent lengths cause speed-compression (fast blocks) or silence-padding (paused blocks)
- ~19–21 words per line for 15s blocks, targeting ~10–11s of speech; each line must finish under ~13s
- Never end a block on a critical word
- Spell out numbers in narration text

## Subtitles

- **Default: NO burned-in subtitles.** Deliver a separate `.srt` file with timestamps for YouTube upload.
- If burned subtitles are requested: use **Patrick font, never Anton** — Anton is too wide/condensed and clips outside the 720px vertical frame. Patrick wraps safely on mobile/Shorts.

## Character & style consistency

- Generate ONE character reference image first via `nano_banana_pro`, then attach to every scene as `image_references`
- For a recurring mascot/character, generate it once and reuse its reference ID on every scene (verify the ID via `show_reference_elements` / `show_generations`)
- Known artifact: orbiting cameras past repeating architecture cause morphing/warping. Fix: locked-off tripod composition, single solid subject, blurred background, explicit negatives against warping/duplicating architecture

## Content formats that work

- **Myth-flip / curiosity-gap** is a proven Shorts format: open with a surprising claim, hold the payoff to the end
- **Antidote-style 4-block structure**: hook → name the concept/book → real-world application → payoff/CTA
- Hook levers: fear/surprise, authority framing, curiosity gap, personal stakes (name specific things the viewer has)
- Deliver value in the first 2 seconds; no intro/logo

## Channels (define your own)

Keep a short profile per channel so style stays consistent. Template:
| Channel | Niche | Style | Narrator voice |
|---|---|---|---|
| _your channel_ | _history / finance / how-to / …_ | _photorealistic cinematic / 2D vector / claymation / …_ | _chosen preset_ |

## Delivery package (every video, no exceptions)

1. Final MP4 (widget or direct CloudFront link)
2. `.srt` subtitle file (created via `create_file`, timestamps matched to blocks)
3. 9:16 thumbnail (nano_banana_pro) with bold curiosity-gap text + channel tag
4. Copy-paste YouTube metadata: title (with emoji where fitting), description, hashtags/tags; chapters for long-form
5. Cost summary in credits
6. Note that Claude cannot hear audio — recommend one watch-through before upload; offer surgical single-block regeneration by timestamp/phrase

## Fix paths (cheapest first)

| Problem | Fix |
|---|---|
| One bad clip | Regenerate that clip only, reassemble (assembly free) |
| Subtitle clipping | Reassemble with Patrick font (~0.30 credits) |
| Audio fast/paused/truncated | Re-voice affected blocks to uniform pacing rules above |
| Wrong aspect/framing | Regenerate fresh — NEVER `reframe` |
| NSFW false positive | Reword prompt euphemistically, keep historical framing |
| 429 rate limit | Batch to ~6 concurrent, retry after wait |
| 404 on assembly | A job is still pending — check `show_generations`, wait, retry |
