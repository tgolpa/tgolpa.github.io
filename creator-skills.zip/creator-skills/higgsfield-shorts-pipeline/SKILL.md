---
name: higgsfield-shorts-pipeline
description: End-to-end YouTube video production pipeline using Higgsfield MCP tools. ALWAYS use this skill whenever the user asks to make, script, voice, assemble, fix, or regenerate a YouTube Short or long-form video, mentions Higgsfield, seedance, explainer_video, nano_banana_pro, voiceover/narration generation, subtitles/SRT, thumbnails, or stick-figure/hand-sketch Shorts — even if they don't say "pipeline." First presents a full pre-production treatment for approval — script, per-scene image prompts, per-block audio/voice, thumbnail, and copy-paste YouTube title/description/tags — THEN generates. For sketch Shorts it can render Ken Burns motion LOCALLY with ffmpeg (bundled scripts/build.sh) instead of paying seedance per clip (~5 cr vs ~210 cr/video), and includes a competitor tag/SEO teardown method. Encodes critical tool workarounds, voice settings, assembly ordering, and delivery-package standards that prevent wasted credits and broken output.
---

# Higgsfield Shorts Production Pipeline

A credit-efficient workflow for producing YouTube Shorts and long-form videos via the Higgsfield MCP connector. Follow this exactly — every rule below was learned by burning credits on the alternative.

> **Setup (one-time):** this skill drives the **Higgsfield MCP connector**, which you add to Claude Code yourself and sign into with your **own Higgsfield account** (video/image/audio generation spends *your* credits). See the bundle README for how to connect it. The skill is the "how"; your Higgsfield account is the engine.

Working style: fast execution, minimal back-and-forth, production-ready deliverables. Default to acting; ask only when a choice genuinely changes cost or output.

## Step 0 — Pre-production treatment (ALWAYS present this for approval BEFORE generating anything)

Generation costs credits; planning is free. Before submitting a single `generate_*` job, chart the ENTIRE video as one treatment and show it to the user for a yes/edits. This is the most important habit — it catches problems while they are free to fix. Deliver the whole thing in one message:

- **Concept & hook** — the one-line premise + the exact first-2-seconds hook line.
- **Full narration script**, split into the numbered fixed-length blocks you will actually voice (obey the pacing/word-count rules below). Each block = the verbatim narration text.
- **Per-block shot list** — a table with ONE ROW PER BLOCK, columns:
  - **Image/scene prompt** — the exact `nano_banana_pro` / `generate_video` prompt (subject, composition, lighting, camera, style, negatives) that makes that clip.
  - **Audio** — that block's narration line + any ambient/SFX note, plus the **voice preset** + `speech_rate` it uses.
  - **On-screen** — any text/emphasis (usually none baked in; note it for thumbnail/SRT).
- **Character/style reference plan** — the one reference image to generate first and reuse everywhere.
- **Thumbnail** — image prompt + the bold curiosity-gap text overlay.
- **YouTube metadata** — proposed title (emoji if fitting), description, tags/hashtags, and chapters for long-form — all copy-paste ready.
- **Estimated credit cost** + the generation order.

Present it clean and skimmable (numbered blocks + the shot-list table). Only after the user approves or edits do you run the generation steps below. If they say "just make it," STILL show the treatment first, then proceed unless they flag a change — the point is they SEE the full package before credits burn, not that they must reply.

## Pipeline overview (standard order)

0. **Present the Step 0 treatment for approval** (script + per-scene image prompts + per-block audio + thumbnail + metadata + cost) — never skip this
1. **Script** the video in fixed-length blocks (see Script rules)
2. **Character/style reference** via `nano_banana_pro` (if characters or consistent style needed)
3. **Submit ALL audio first** via `generate_audio` (fastest to complete)
4. **Submit video clips** via `generate_video` (seedance_2_0, fast mode, 720p) — OR render locally (see Production mode B)
5. **Verify completion** via `show_generations` — the ONLY way to check job status (no polling tool exists)
6. **Assemble** via `explainer_video` only after every job shows completed — OR concat locally with ffmpeg (mode B)
7. **Deliver package**: final MP4 link + SRT + thumbnail + copy-paste metadata

## Production modes (pick one before scripting)

### A. Animated scenes (default for photorealistic / claymation / cinematic channels)
Full `generate_video` scenes with motion, characters, camera moves. ~52.5 cr per 15s clip (fast / 720p). Use when real motion (people moving, camera moves, action) is the point.

### B. Static-sketch mode — LOCAL ffmpeg render (huge credit saver for illustration/sketch Shorts)

**This is the credit breakthrough. Do NOT animate stills with seedance for a still-illustration channel.** Seedance "one subtle motion" on a still costs ~3.5 cr/sec (~210 cr for a 60s Short). Rendering the same "filmed illustration" look **locally with ffmpeg is free** and brings a full Short to ~5 cr total (stills + audio only). It also fixes the audio-truncation defect, because each clip's length == its full narration take.

Requires **ffmpeg** on your machine (`brew install ffmpeg` on a Mac). Workflow:
1. **Script** ~125 words / 6 scenes (≈54–58s final). The closer must ANSWER the title's hook, not just restate it.
2. **All audio** via `generate_audio` (see Voice settings). Batch in **≤8 concurrent** — the voice engine 429s above that; retry the rest after ~30s.
3. **One still per scene** via `nano_banana_pro` (~2 cr each). Always append: *"Fill the entire frame edge to edge, no border, no notebook, no photograph framing."* (reduces the "photographed-notebook page" artifact — the build crops the rest).
4. **Download** each asset from the `rawUrl` in `show_generations` — **never guess** the `hf_<timestamp>_<id>` filename (guessing 403s).
5. **`scripts/build.sh`** (bundled, macOS/Linux) does everything else in one command: silence-trim → tempo nudge to guarantee ≤60s → Ken Burns `zoompan` clip sized to each take → 5.5% inset-crop (kills notebook borders) → vignette → concat → **prints exact per-scene timestamps for the SRT**. Copy it into the episode folder, put stills+takes in `./assets` as `s1.png…sN.png` / `a1.wav…aN.wav`, edit `OUT`/`TEMPO` at the top, run `bash build.sh`.
   - `TEMPO` is calibrated by TOTAL RAW narration length, not scene count: ~48–52s raw → **1.0** (don't needlessly speed up a naturally short story); ~55–62s → **1.05**; ~65–72s (poetic/comma-list scripts run long) → **1.15–1.22**. Build every under-60s cut at 1.0 unless it's actually over. The script warns if over 60.
   - **One take anomalously long?** The voice engine sometimes over-pauses comma-lists (a 20-word line comes back 14–18s). Re-voice THAT ONE take with tighter wording (drop a comma clause) rather than cranking global tempo — keeps the other scenes at natural pace. Better still: write tight lines (~18–20 words, avoid 3+ comma lists) up front.
   - Verify a batch of stills cheaply with an ffmpeg `xstack` contact sheet (one image to read) instead of reading each still.
   - Bad single scene: regenerate that one still (~2 cr) and re-run build (free). Never redo the whole video.

Sketch house style: hand-drawn ink and pencil on textured paper, cross-hatching, sepia and charcoal tones, **one warm accent color** per frame, contemplative sketchbook feel. A "stick-figure" variant uses simple stick figures in that same style.

*Fallback* (no ffmpeg, or motion genuinely needed): the seedance path — animate each still with minimal-motion prompting ("stays almost completely still… only [ONE subtle motion]… no redrawing, no style change, preserve the exact artwork. No text"), name exactly ONE motion, then assemble via `explainer_video`.

## Competitor teardown (tag/format + SEO research — do this before scripting in a new niche)

Reverse-engineer a proven channel's virality recipe in a few browser calls, then model the FORMAT (never copy the topic).

1. Find a channel in your niche + its single best-performing video (search YouTube, sort by popular). Note the view outliers — those are the format that's working.
2. On the video page, pull its exact tags with browser JS: `ytInitialPlayerResponse.videoDetails.keywords` (also `meta[name="keywords"]`). This is the real ranked tag list, not a guess.
3. Distill the formula: **title** shape (curiosity-gap questions that match the opening line), **tag** pattern, **description** opener.
4. **Combined tag recipe** = one long-tail question phrasing (how someone actually searches) + a *niche-topic cluster* (5–6 terms a viewer/algorithm associates with your subject) + *authority/credibility words* (the field's serious vocabulary). ~20 tags total. Open the description with an SEO subtitle using pipe separators ("How compound interest really works | The money lesson schools skip | …").
5. Match the video's first spoken line to the title (the payoff landing in the second line is what drives Shorts retention).

The [companion **reference-video-adaptation** skill] does this teardown → script-package step in depth; use it to turn a reference video into a ready-to-produce treatment, then bring it here.

## Sensitive topics (money claims, health, death, taboo) — keep it advertiser-safe & defensible

Some topics travel well on curiosity but attract fact-checkers and demonetization. Keep them defensible:
- **Frame as education, not advice/how-to.** For finance especially: explain concepts and history, **never give personalized investment advice or "buy this" calls** — that's both a policy and a trust risk. Add "not financial advice" where relevant.
- **NO operational detail on genuinely risky subjects** (substances, self-harm-adjacent history, medical): no dosing, no instructions, symbolic visuals only, historical/anthropological framing.
- **Hedge every claim** ("may," "likely," "one study found") and **cite the real source** in the metadata sourcing block so it survives virality.
- **Put disclaimers in the PINNED COMMENT**, not the narration — keeps the video clean while covering you.

## More format levers (beyond the myth-flip)

- **Self-demonstrating hook** = strongest comment-bait. If the topic is something the video itself can trigger in the viewer, open by triggering it and bait the comment ("did that surprise you? 👇"). Rare but gold for Shorts ranking.
- **Companion episodes**: split a big theme into two cross-linked Shorts and cross-link them in each pinned comment for cross-traffic/retention. Same asset style, cheap second video.
- **Fact-check first**: before scripting, web-verify the 1–2 hardest *checkable* numbers (percentages, dates) and write the citations straight into the metadata sourcing block. Cheap insurance; credibility channels win on it.

## Critical tool behaviors (non-negotiable)

- **seedance calls**: include the `declined_preset_id` workaround on EVERY call (known offending presets: `24bae836...` and `cb116576...`). Without it, unwanted presets attach.
- **`explainer_video`**: submitting with pending job IDs returns **404** (it does not queue). All audio + video jobs must show completed in `show_generations` first (`type: video`, `size: 8` to confirm clips).
- **`explainer_video` does NOT accept a background music parameter.** Don't attempt it. If music is wanted: generate it separately (text-to-music, duration in seconds) and deliver the audio file alongside the video for the user to layer in CapCut / the YouTube Shorts editor at ~20% volume — this gives them mix control anyway.
- **`explainer_video` requires a MINIMUM of 2 items.** A single-scene Short is impossible. If the content is one scene, add a short (5-6s) outro clip with a closing line.
- **The same video clip may be reused across multiple items** with different audio — useful when one illustration covers two narration lines. Cheap way to stretch art across more script.
- **1080p requires `mode: "std"` (135 cr / 15s), NOT `mode: "fast"`** — fast mode caps at 720p and errors on 1080p. Default to 720p/fast unless the user explicitly demands 1080p; the cost difference is ~2.5x.
- **NEVER use `reframe`** — it costs more than regenerating the clip fresh. Regenerate instead.
- **`nano_banana_pro` NSFW filter false-positives on death imagery** (skulls, corpses, executions). Reword prompts euphemistically ("fallen figure," "still form," historical framing) rather than fighting the filter.
- **Rate limit**: ~6 concurrent seedance jobs. On 429, wait and retry remaining jobs in batches.
- **Assembly is free**; re-running caption transcription costs ~0.30 credits. Regenerating a single clip + reassembling is the cheap fix path — never redo the whole video for one bad block.
- **Gemini Omni** requires a paid Higgsfield plan (403 on free tier). Kling 3.0 Turbo is the text-to-video fallback but does not accept image references the same way. Style key images from `nano_banana_pro` pass to Gemini Omni clips via `role: image` in the `medias` array using the job ID.

## Cost cheat sheet (check `balance` before any multi-scene run)

| Item | Cost |
|---|---|
| seedance fast / 720p | ~3.5 cr per second (15s = 52.5, 10s = 35, 6s = 21) |
| seedance std / 1080p | 135 cr per 15s — **2.5x**; only on explicit request |
| `nano_banana_pro` image | ~2–6 cr |
| `generate_audio` take | ~0.5–1 cr |
| `explainer_video` assembly | **free** |
| local ffmpeg render (mode B) | **free** (only stills + audio cost credits ≈ ~5 cr/video) |
| `reframe` | 73.5 cr / 15s — **never use**, regenerating is cheaper |

Use `get_cost: true` for a preflight when unsure. Run `balance` before a large batch; a mid-run out-of-credits failure strands half-finished work.

## Video specs

- **Shorts**: 9:16 vertical, `width: 720, height: 1280`, seedance_2_0 fast mode, 720p
- **Long-form**: 16:9, `width: 1280, height: 720`
- Blocks: typically 10s or 15s windows; total Short runtime ~40–60s
- Photorealistic unless the channel style says otherwise; ambient audio off (narration laid over at assembly); no on-screen text baked into clips

## Voice settings

Higgsfield ships stock preset voices. Pick one per channel and stay consistent. **Always confirm the exact `voice_id` UUID via `list_voices` in your own account before submitting — do not guess IDs.** `generate_audio` uses `voice_type: preset` with the UUID `voice_id`.

Example pairing pattern (choose voices that fit your niche):
| Role | Example voice | Settings |
|---|---|---|
| Default narrator (deep male documentary) | e.g. a deep British/documentary male preset | `speech_rate: -10` |
| First-person / warmer narration | e.g. a female preset | default rate |

### Audio truncation fix (standard on ALL final blocks)

Final narration blocks get clipped at the block boundary — the single most recurring defect in this pipeline. **Apply the full fix preemptively on every closing block; do not wait for the user to report a clip.**

Standard preemptive recipe:
- Final block uses `speech_rate: -5` (not -10)
- Place the critical phrase **mid-sentence**, followed by a disposable tail ("Good luck." / "Enjoy." / a short sign-off)
- Target **~7 seconds of speech in a 10-second window** — a large margin, not a tight one

**Escalation ladder** if a user still reports a clipped ending (each step is ~1 credit + free reassembly):
1. Restructure so the key phrase is mid-sentence with a tail after it
2. Still clipping? The take is simply **too long** — cut the line shorter (target ~7s)
3. Still clipping? The closing *video clip* is shorter than expected — regenerate that clip at a confirmed 10s (~35 cr) rather than touching audio again

Claude cannot hear audio. Never claim a truncation is fixed as verified fact — say what was changed and ask for one listen.

### Pacing rules (all blocks)

- Uniform take lengths across blocks — inconsistent lengths cause speed-compression (fast blocks) or silence-padding (paused blocks)
- ~19–21 words per line for 15s blocks, targeting ~10–11s of speech; each line must finish under ~13s
- Never end a block on a critical word
- Spell out numbers in narration text

## Subtitles

- **Default: NO burned-in subtitles.** Deliver a separate `.srt` file with timestamps for YouTube upload.
- If burned subtitles are requested: use **Patrick font, never Anton** — Anton is too wide/condensed and clips outside the 720px vertical frame. Patrick wraps safely on mobile/Shorts.

## Character & style consistency

- Generate ONE character reference image first via `nano_banana_pro`, then attach to every scene as `image_references`
- For a recurring mascot/character, generate it once and reuse its reference ID on every scene (verify the ID via `show_reference_elements` / `show_generations`)
- Known artifact: orbiting cameras past repeating architecture cause morphing/warping. Fix: locked-off tripod composition, single solid subject, blurred background, explicit negatives against warping/duplicating architecture

## Content formats that work

- **The object myth-flip.** *Iconic/familiar object + "it was never meant to do what you think" + ~40s.* Structure: creepy/iconic visual hook → the assumption is wrong → what it was actually for → a closing fact that reframes it. Works for history, everyday objects, money myths, etc.
- **The everyday-universal reveal.** *Something every viewer does or believes → the forgotten history or hidden mechanism behind it.* Hook by naming the exact thing the viewer will do or feel tomorrow.
- **Antidote-style 4-block structure** (great for finance/how-to): hook → name the concept/book → real-world application → payoff/CTA.
- **Myth-flip / curiosity-gap** generally: open with a surprising claim, hold the payoff to the end.
- Hook levers: fear/surprise, authority framing, curiosity gap, personal stakes (name specific things the viewer has).
- Deliver value in the first 2 seconds; no intro/logo.

**Research layer is part of the format.** Credibility channels win on it — fact-check every claim, hedge honestly in the narration ("one theory says…", "as far as we can tell…"), and surface the sourcing in the delivery message so the creator can defend it if the video goes big.

## Channels (define your own)

Keep a short profile per channel so style stays consistent. Template:
| Channel | Niche | Style | Narrator voice |
|---|---|---|---|
| _your channel_ | _history / finance / how-to / …_ | _photorealistic cinematic / 2D vector / claymation / sketch_ | _chosen preset_ |

## Channel art (banner + profile picture)

- **Banner**: 16:9, generate at `resolution: 2k` (satisfies YouTube's 2048×1152 minimum). YouTube crops banners hard and differently per device (TV = full, desktop = wide strip, mobile = narrow center sliver) — so **keep the title text and all key subjects inside the horizontal center band**. Prompt this explicitly.
- **Profile picture**: 1:1. Prompt the subject to occupy only the **central ~50% of the frame with generous margin on all sides**, so the circular crop never clips it. No text — at small sizes lettering turns to mush; one bold object reads instantly.
- Color-match the profile pic to the banner grade so the channel page reads as one designed brand.
- **Claude cannot compress or re-encode files.** If a banner exceeds YouTube's 6MB limit, re-save it locally as JPEG (quality ~90) — same resolution, ~1–2MB, no visible loss. Don't regenerate at lower resolution.

## Metadata optimization (apply to every upload package)

- **Front-load the search phrase** in the first line of the description — YouTube weights the opening ~100 characters most. Lead with how someone would actually search for it, not a clever framing.
- **Max 3 hashtags shown** above a Short's title — put the highest-value ones first; ~6 total is plenty. Eight+ dilutes.
- **Add comment bait** — comments are a strong Shorts ranking signal ("👇 What's the first thing you'd try?").
- **Add a subscribe/series line** where a series exists.
- **Be precise with credentials.** State exactly what is true, never an inflated shorthand — it must survive scrutiny if the video goes big.
- **Retitle as a growth lever**: if a Short plateaus, changing the title triggers YouTube re-evaluation and can produce a second distribution push on the same upload.
- Title formats that work: number + curiosity gap, or command + reversal. **The title should match the video's opening line** — payoff in the second line boosts retention, which drives Shorts distribution.

## Delivery package (every video, no exceptions)

1. Final MP4 (widget or direct CloudFront link)
2. `.srt` subtitle file (created via `create_file`, timestamps matched to blocks)
3. 9:16 thumbnail (nano_banana_pro) with bold curiosity-gap text + channel tag
4. Copy-paste YouTube metadata: title (with emoji where fitting), description, hashtags/tags; chapters for long-form
5. Cost summary in credits
6. Note that Claude cannot hear audio — recommend one watch-through before upload; offer surgical single-block regeneration by timestamp/phrase

## Fix paths (cheapest first)

| Problem | Fix |
|---|---|
| One bad clip | Regenerate that clip only, reassemble (assembly free) |
| Subtitle clipping | Reassemble with Patrick font (~0.30 credits) |
| Audio fast/paused/truncated | Re-voice affected blocks to uniform pacing rules above |
| Wrong aspect/framing | Regenerate fresh — NEVER `reframe` |
| NSFW false positive | Reword prompt euphemistically, keep historical framing |
| 429 rate limit | Batch to ~6 concurrent, retry after wait |
| 404 on assembly | A job is still pending — check `show_generations`, wait, retry |
| Closing line still clips after re-voice | Climb the escalation ladder: shorten the take, then regenerate the closing clip at a confirmed 10s |
| Only one scene of content | `explainer_video` needs ≥2 items — add a 5-6s outro clip with a closing line |
| Music requested | Generate separately, deliver as a separate file to layer in CapCut / Shorts editor |
| Banner over 6MB | Cannot compress — re-save locally as JPEG q90 |
| Paying too much on a still-image channel | Switch to Production mode B (local ffmpeg render) — ~5 cr vs ~210 |
