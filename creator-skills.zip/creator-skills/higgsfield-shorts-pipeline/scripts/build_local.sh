#!/usr/bin/env bash
# LOCAL block assembler for narrated cuts (one commissioned clip + one narration take per block) - macOS / Linux.
# Copy this into an episode folder. Put clips + takes in ./assets (or fill DOWNLOADS and it fetches them),
# then run:  bash build_local.sh
#
# Does: per block, lay the take over the clip at the clip's TRUE length -> concat -> ffprobe the result
#       -> PASS/FAIL against the sum of the block lengths -> prints per-block timestamps for the SRT.
# Reusable per episode: edit BLOCKS (and DOWNLOADS / OUT), drop in assets, run.  Assembly is free.
#
# WHY local instead of explainer_video: the hosted assembler forces EVERY block into a 10-second
# window no matter how long the clip is. Measured 2026-08-03: a 12-block cut with six 15 s clips
# (150.5 s of source) came back exactly 120 s - each 15 s block lost its final third and its
# narration was sped up ~25%. That is the root cause of the "audio truncation" defect, and it
# throws away a third of every 15 s clip you paid 52.5 cr for.
#
# WHEN: any commissioned clip is longer than 10 s, or any narration take is longer than ~8.5 s.
#       Under both limits the hosted assembler is fine (and free); above either one, use this.
#
# Requires ffmpeg + ffprobe:  brew install ffmpeg   (Mac)   /   apt install ffmpeg   (Linux)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ASSETS="$SCRIPT_DIR/assets"
mkdir -p "$ASSETS"

command -v ffmpeg  >/dev/null 2>&1 || { echo "ffmpeg not found.  Install: brew install ffmpeg";  exit 1; }
command -v ffprobe >/dev/null 2>&1 || { echo "ffprobe not found. Install: brew install ffmpeg";  exit 1; }

# ---------------- EDIT PER EPISODE ----------------
OUT="episode_final.mp4"             # final filename (written next to this script)

# Optional: assets to fetch before building, one "url|save-as" per line. Paste the FULL rawUrl
# from show_generations - never guess the hf_<timestamp>_<id> filename (guessing 403s).
# Files already in ./assets are skipped.
DOWNLOADS=(
  # "https://<rawUrl from show_generations>/hf_20260803_123614_xxxxxxxx.mp4|clip_01.mp4"
  # "https://<rawUrl from show_generations>/hf_20260803_123044_xxxxxxxx.wav|take_01.wav"
)

# One row per block, in play order:  "n|clip|wav|delay_ms|dur_seconds"
#   n     = two-digit block number (names block_NN.mp4 and fixes concat order)
#   clip  = video file in ./assets           wav = narration take in ./assets
#   delay = narration start offset INSIDE the clip, in ms (0 = starts with the picture)
#   dur   = the clip's TRUE length in seconds, from:
#             ffprobe -v error -show_entries format=duration -of csv=p=0 ./assets/clip_01.mp4
#           NOT a 10 s assumption - that assumption is exactly what the hosted assembler gets wrong.
BLOCKS=(
  "01|clip_01.mp4|take_01.wav|0|10.041667"
  "02|clip_02.mp4|take_02.wav|0|15.041667"
)
# --------------------------------------------------

[ "${#BLOCKS[@]}" -gt 0 ] || { echo "BLOCKS is empty - fill the table at the top of build_local.sh"; exit 1; }

# ${arr[@]+"${arr[@]}"} is the empty-array-safe expansion: macOS ships bash 3.2, where a plain
# "${DOWNLOADS[@]}" on an empty array trips set -u.
for entry in ${DOWNLOADS[@]+"${DOWNLOADS[@]}"}; do
  IFS='|' read -r url as <<< "$entry"
  dst="$ASSETS/$as"
  if [ -f "$dst" ]; then echo "have    $as"; continue; fi
  echo "fetch   $as"
  curl -fsSL -o "$dst" "$url"
done

# Pre-flight: every input must exist BEFORE the first encode. A 12-block encode is minutes of
# work; finding the typo at block 9 throws the first eight away.
for entry in "${BLOCKS[@]}"; do
  IFS='|' read -r n clip wav delay dur <<< "$entry"
  [ -f "$ASSETS/$clip" ] || { echo "block $n: missing $ASSETS/$clip. Add its rawUrl to DOWNLOADS or fix the clip name in BLOCKS."; exit 1; }
  [ -f "$ASSETS/$wav" ]  || { echo "block $n: missing $ASSETS/$wav. Add its rawUrl to DOWNLOADS or fix the wav name in BLOCKS.";  exit 1; }
done

# Per block: resample the take to 48 kHz, delay it to where it starts inside the clip, pad with
# silence, trim to the clip's true length, force stereo, mux over the clip's video. Exactly the
# filter that rebuilt the 2m30s cut; do not "simplify" it - apad without atrim runs forever,
# atrim without apad leaves a block whose audio ends before its picture does.
expected=0
: > "$ASSETS/concat.txt"
for entry in "${BLOCKS[@]}"; do
  IFS='|' read -r n clip wav delay dur <<< "$entry"
  clipPath="$ASSETS/$clip"; wavPath="$ASSETS/$wav"; outPath="$ASSETS/block_${n}.mp4"

  flt="[1:a]aresample=48000,adelay=${delay}:all=1,apad,atrim=0:${dur},aformat=channel_layouts=stereo[a]"
  ffmpeg -y -v error -i "$clipPath" -i "$wavPath" -filter_complex "$flt" \
    -map 0:v -map "[a]" -c:v libx264 -crf 18 -preset fast -pix_fmt yuv420p -c:a aac -b:a 192k \
    "$outPath"

  # concat demuxer: MUST use relative filenames (an apostrophe in the path breaks absolute paths)
  echo "file 'block_${n}.mp4'" >> "$ASSETS/concat.txt"
  expected=$(awk "BEGIN{print $expected + $dur}")
  printf "block %s ok  (%ss, narration from %s ms)\n" "$n" "$dur" "$delay"
done

( cd "$ASSETS" && ffmpeg -y -v error -f concat -safe 0 -i concat.txt -c copy "../${OUT}" )

# The post-assembly gate, run on our own output: the same ffprobe the skill demands before delivery.
got=$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$SCRIPT_DIR/$OUT")
TOL=0.5
echo "----"
printf "blocks: %d   expected (sum of dur): %.3fs   got: %.3fs   ->  %s\n" "${#BLOCKS[@]}" "$expected" "$got" "$OUT"
if awk "BEGIN{d=$got-$expected; if (d<0) d=-d; exit !(d<=$TOL)}"; then
  echo "PASS  duration matches the sum of the block lengths (tolerance ${TOL} s)"
else
  printf "FAIL  duration is off by %.3fs. A block did not encode at its clip length: re-check each dur against ffprobe and re-run.\n" "$(awk "BEGIN{print $got-$expected}")"
  exit 1
fi

# cumulative timestamps (seconds) - convert to hh:mm:ss,ms for the .srt; narration in a block starts at start + delay
acc=0
for entry in "${BLOCKS[@]}"; do
  IFS='|' read -r n clip wav delay dur <<< "$entry"
  start=$acc
  acc=$(awk "BEGIN{print $acc + $dur}")
  printf "B%s  %.3f --> %.3f   (narration from %.3f)\n" "$n" "$start" "$acc" "$(awk "BEGIN{print $start + $delay/1000}")"
done
