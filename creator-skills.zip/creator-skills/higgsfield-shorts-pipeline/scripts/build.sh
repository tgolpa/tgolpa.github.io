#!/usr/bin/env bash
# Local sketch-Short render pipeline (zero Higgsfield motion credits) — macOS / Linux.
# Copy this into an episode folder. Put stills + takes in ./assets as s1..sN.png / a1..aN.wav,
# then run:  bash build.sh
#
# Does: silence-trim each take -> tempo nudge to fit <=60s -> Ken Burns clip sized to each take
#       -> concat -> prints exact per-scene timestamps for the SRT.  Assembly is free.
#
# WHY local instead of seedance: seedance "one subtle motion" on a still costs ~3.5 cr/sec
# (~210 cr for a 60s Short). ffmpeg zoompan gives the same "filmed illustration" look for $0
# and makes clip length == full narration length (kills the audio-truncation defect too).
#
# Requires ffmpeg + ffprobe:  brew install ffmpeg   (Mac)   /   apt install ffmpeg   (Linux)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIR="$SCRIPT_DIR/assets"

# ---------------- EDIT PER EPISODE ----------------
OUT="episode_SHORT_1080x1920.mp4"   # final filename (written next to this script)
TEMPO=1.05                          # calibrate by RAW total, not scene count:
                                    #   ~48-52s -> 1.0   ~55-62s -> 1.05   ~65-72s -> 1.15-1.22
                                    # If ONE take is anomalously long (14-18s), re-voice THAT take
                                    # tighter instead of raising this.
# --------------------------------------------------

command -v ffmpeg  >/dev/null 2>&1 || { echo "ffmpeg not found.  Install: brew install ffmpeg";  exit 1; }
command -v ffprobe >/dev/null 2>&1 || { echo "ffprobe not found. Install: brew install ffmpeg";  exit 1; }
[ -d "$DIR" ] || { echo "No ./assets folder next to build.sh (expected $DIR)"; exit 1; }

# count scenes by the a*.wav takes present
N=$(find "$DIR" -maxdepth 1 -name 'a*.wav' | wc -l | tr -d ' ')
[ "$N" -gt 0 ] || { echo "No a1.wav.. takes found in $DIR"; exit 1; }

# trim leading+trailing silence, then nudge tempo (pitch-preserving; inaudible at a deep -10 voice)
TRIM="silenceremove=start_periods=1:start_silence=0:start_threshold=-45dB:detection=peak,areverse,silenceremove=start_periods=1:start_silence=0:start_threshold=-45dB:detection=peak,areverse,atempo=${TEMPO}"

durs=()
total=0
: > "$DIR/concat.txt"

for ((i=1; i<=N; i++)); do
  img="$DIR/s${i}.png"; aud="$DIR/a${i}.wav"; audt="$DIR/t${i}.wav"
  [ -f "$img" ] || { echo "Missing still: $img"; exit 1; }
  [ -f "$aud" ] || { echo "Missing take: $aud";  exit 1; }

  ffmpeg -y -loglevel error -i "$aud" -af "$TRIM" "$audt"
  D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$audt")
  durs+=("$D")
  total=$(awk "BEGIN{print $total + $D}")
  Nf=$(awk "BEGIN{print int($D*30)+3}")   # frame count for the zoompan (headroom over take length)

  # odd scenes zoom IN, even scenes zoom OUT (gentle Ken Burns alternation)
  if (( i % 2 == 1 )); then z="1.0+0.12*on/${Nf}"; else z="1.12-0.12*on/${Nf}"; fi

  # crop=iw*0.89 -> trims any photographed-notebook border nano_banana sometimes adds
  vf="crop=iw*0.89:ih*0.89,scale=2160:3840:force_original_aspect_ratio=increase,crop=2160:3840,zoompan=z=${z}:d=${Nf}:x=iw/2-(iw/zoom/2):y=ih/2-(ih/zoom/2):s=1080x1920:fps=30,vignette=a=PI/7,setsar=1"

  ffmpeg -y -loglevel error -loop 1 -i "$img" -i "$audt" -vf "$vf" \
    -map 0:v -map 1:a -t "$D" -r 30 \
    -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -c:a aac -b:a 160k \
    "$DIR/clip${i}.mp4"

  printf "clip%d: %.3fs\n" "$i" "$D"
  # concat demuxer: MUST use relative filenames (an apostrophe in the path breaks absolute paths)
  echo "file 'clip${i}.mp4'" >> "$DIR/concat.txt"
done

( cd "$DIR" && ffmpeg -y -loglevel error -f concat -safe 0 -i concat.txt -c copy "../${OUT}" )

echo "----"
printf "TOTAL: %.3fs  ->  %s\n" "$total" "$OUT"
if awk "BEGIN{exit !($total>60)}"; then
  echo "WARNING: over 60s. Raise TEMPO (e.g. 1.15) or shorten a take, then re-run."
fi

# cumulative SRT timestamps (seconds) — convert to hh:mm:ss,ms for the .srt
acc=0
for ((k=0; k<${#durs[@]}; k++)); do
  start=$acc
  acc=$(awk "BEGIN{print $acc + ${durs[$k]}}")
  printf "S%d  %.3f --> %.3f\n" "$((k+1))" "$start" "$acc"
done
