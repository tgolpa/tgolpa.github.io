---
name: reference-video-adaptation
description: "Analyze-then-adapt workflow — deconstruct a reference YouTube video or channel into its format levers, then port that structure to YOUR niche as a production-ready script package. ALWAYS use this skill whenever the user shares a YouTube link or channel for analysis, asks to model/copy/emulate a video's style or format, says 'make one like this but about X,' or asks why a video/format works — even if they don't ask for a script explicitly. Output feeds directly into the higgsfield-shorts-pipeline skill."
---

# Reference Video Format Analysis & Niche Adaptation

Recurring workflow: take a reference video/channel → extract WHY it works → transplant the skeleton (never the topic) into YOUR niche → deliver a script package ready for the Higgsfield pipeline.

Rule one: **model the format, change the topic entirely.** Never produce a same-topic knockoff — that's how you get lost in the crowd (and risk a copy). You are stealing the *structure*, not the subject.

## Step 1 — Analyze the reference

Fetch/search what's available about the video and channel. If YouTube rate-limits or the channel can't be verified, say so plainly and flag it as a known gap — never invent channel details. If you can open the video page in a browser, pull its real tags with JS: `ytInitialPlayerResponse.videoDetails.keywords`.

Break down:

1. **Niche, style, audience** — who clicks this and why; faceless / AI-produced signals (AI voiceover, stock or AI b-roll, multi-language twins = a mass-production operation you can emulate cheaply).
2. **Structure / format** — beat map with rough timestamps: hook → escalation → payoff → CTA; where value lands (must be in the first ~2 seconds; no logo/intro).
3. **Hook levers** — identify which are stacked:
   - **Fear/surprise** — a threat or fact you didn't know existed
   - **Authority framing** — "scientists/experts say," named institutions, quotable expert lines
   - **Curiosity gap** — withheld payoff ("it's not what you'd guess")
   - **Personal stakes** — naming specific things the viewer owns/does so it feels targeted
   - **Myth-flip** — "everything you know about X is wrong"
4. **Why it wins on Shorts/YouTube** — instant hook, one clear idea, constant visual motion, narration pace, a curiosity loop held to the payoff.

## Step 2 — Port to YOUR niche

Swap the subject domain while keeping the lever stack and beat timing. The reference's *shape* is the asset. Examples of the move:
- "hidden geological threat" (doomsday-science channel) → "hidden money lesson from history" (finance channel)
- countdown-list pacing → "the 5 money mistakes that quietly cost you the most"
- etymology hook → "the word 'salary' comes from *salt* — here's why that still matters"

Keep a short profile of your target channel(s) so the adapted script stays on-brand:
| Channel | Niche | Style | Narrator |
|---|---|---|---|
| _your channel_ | _finance / history / how-to / …_ | _cinematic / 2D vector / claymation / sketch_ | _chosen voice preset_ |

For a **finance/behavioral-money** channel, the "Antidote" 4-block structure ports well: hook → name the concept/book → real-world application → payoff/CTA. Keep it educational, never personalized investment advice.

## Step 3 — Deliver the script package

Standard deliverable (text only unless production is requested):

1. **Reference breakdown** (the Step 1 analysis, concise)
2. **Scene-by-scene script** — per scene: timestamp range, narration line, visual description (a paste-ready generation prompt), on-screen text if any
3. **Pacing math** — ~125 words per 55-second Short (~2.3 words/sec); blocks sized to the pipeline's windows (10s or 15s); narration lines must finish inside their window; numbers spelled out; never end a block on a critical word
4. **Metadata** — title (curiosity-gap phrasing, emoji where fitting), description, hashtags/tags
5. **Thumbnail concept** — bold short text + channel tag, 9:16 for Shorts
6. **Shot list** formatted to paste straight into the Higgsfield pipeline (9:16 for Shorts, 16:9 long-form)

If the user says "text only, I'll produce it later myself" — deliver the package with zero generation calls and minimal credits/tokens. If they say produce it, hand off to the **higgsfield-shorts-pipeline** skill and follow it exactly (it opens with a full pre-production treatment for approval before spending any credits).
