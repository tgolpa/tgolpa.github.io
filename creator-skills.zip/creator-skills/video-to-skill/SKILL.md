---
name: video-to-skill
description: Learn a workflow from a YouTube video (or other video/tutorial URL) and turn it into a permanent, tested Claude skill — without buying the creator's paid pack, course, or subscription. Use whenever the user shares a video link and asks to "watch", "analyze", "learn from", "reproduce the steps", or "make a skill from" it, or wants a tutorial's method captured as a reusable capability.
---

# Video → Skill

Turn any tutorial video into a permanent capability. The core insight: **a tutorial's transcript almost always contains the entire method** — the paid pack/course usually just sells the finished artifact. You rebuild the method from what's publicly taught, verify it against real tools, and encode it as a skill so it never has to be re-learned.

## Reference files

| File | When to read |
|---|---|
| [references/transcript-extraction.md](references/transcript-extraction.md) | Step 1 — the extraction ladder (what actually works) |
| [references/distillation.md](references/distillation.md) | Step 2 — turning a transcript into architecture |
| [references/skill-authoring.md](references/skill-authoring.md) | Step 3 — writing the skill files |

## Workflow

### Step 1 — Extract what the video teaches
Follow the ladder in `references/transcript-extraction.md`. You need three things:
1. **Description + chapter timestamps** — the chapters are a free outline of the workflow; the description reveals what's being *sold* vs. what's being *shown*.
2. **Full transcript** — the actual instructions, tool names, prompts, and (critically) the creator's failures and fixes.
3. **License / gating check** — note the video's license (Creative Commons vs. standard) and what the creator gates behind payment. You are reconstructing the publicly-taught method, not pirating a product. Never scrape paid course platforms or leaked content.

### Step 2 — Distill the method (don't transcribe it)
Read `references/distillation.md`. Produce a one-page analysis:
- The **workflow steps** in order (the chapters usually map 1:1).
- The **reusable patterns/architecture** the creator discovered — this is the valuable part, not the surface demo.
- The **failure→fix moments** — when the creator's first attempt fell flat and what they changed. These become the skill's strongest rules (in the Notion-template video, "the engine worked but looked unsellable → mandatory skin pass" was worth more than the whole happy path).
- **What you must verify locally**: tool names, connectors, APIs the video uses. Videos go stale; your environment differs.

### Step 3 — Build the skill
Read `references/skill-authoring.md`. Create it under `~/.claude/skills/<name>/`:
- `SKILL.md` orchestrator (workflow + when-to-read table) plus focused reference files.
- **Verify against reality, not the video**: load the actual MCP tool schemas (ToolSearch) before writing any tool reference file. Write call signatures from the schemas you loaded, never from what the video showed on screen.
- Include a **self-improvement rule**: feedback and discovered gotchas get written back into the reference files, not just applied to one output.

### Step 4 — Smoke test immediately
Run the skill's core loop once, for real, at small scale (the video creator always demos theirs — so do you). Every error you hit is gold: fold the fix into the reference files before finishing. A skill that has never executed is a guess.

### Step 5 — Deliver and record
- Summarize: what the video taught, what the skill does, where it lives, what the smoke test proved, and anything only the user can do (logins, publish toggles, purchases).
- Save a project memory pointing at the new skill.
- Remind the user that personal skills load at session start — the new skill triggers in the *next* session.

## Boundaries
- Reconstruct methods from **publicly viewable** content only. If the method itself is truly behind a paywall (the video is just an ad), say so and stop — don't bypass access controls.
- Don't reproduce transcript text verbatim in deliverables; distill it. Note the video's license in your summary.
- Downloading subtitles for analysis is fine; downloading the video itself is rarely needed — don't.
