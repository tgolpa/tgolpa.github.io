# Skill Authoring Standards

How to write the skill so it actually fires and actually works. Personal skills live at `~/.claude/skills/<kebab-name>/` and load at the *next* session start — tell the user this.

## SKILL.md frontmatter
```markdown
---
name: <kebab-case-name>
description: <what it builds/does> + explicit trigger phrases ("Use whenever the user asks to ...").
---
```
The description is the trigger. Write it for the matcher, not the reader: name the artifacts, the niches, the verbs a user would actually type. A beautiful skill with a vague description never fires.

## Structure
- **SKILL.md = orchestrator only**: the workflow steps, a "reference files → when to read" table, and the non-negotiable rules. Keep it under ~80 lines; push detail into references.
- **Reference files = one concern each** (patterns, tool playbook, formulas/snippets, design/quality bar, recipes/examples, packaging). The executing agent reads only what the current step needs — this keeps context lean, same reason the video used subagents.
- **A recipes/examples file that grows**: instruct that every successful run appends its configuration. This is how the skill compounds.

## Rules that earn their place
1. **Tool references from live schemas only.** Load the MCP tools via ToolSearch and copy signatures/IDs/formats from the schema and from real call results — never from the video or from memory. Record exact gotchas (ID formats, escaping, expanded property syntax) as you hit them.
2. **Encode failure→fix moments as mandatory steps**, phrased as the failure ("a working engine that looks like stacked tables is a failed build") so the executor recognizes it.
3. **Self-improvement rule**: when feedback reveals a gap, decide whether the gap is in the *skill* — if yes, update the reference file in the same session and say so.
4. **Quality gate the output**: end the workflow with a QA checklist written from the buyer's/user's perspective, not the builder's.

## Smoke test protocol
1. Run the skill's core loop once at minimum viable scale (one small real artifact, not a mock).
2. Use the least intrusive real destination (private page, scratch folder, test workspace) and tell the user where, so they can delete it.
3. Every error → fix it → append the gotcha to the relevant reference file *before* finishing.
4. Fetch/verify the final artifact as a consumer would; don't trust create-call success alone.

## Finish
- Deliverable summary: skill path, files, what the smoke test proved, manual steps only the user can do.
- Save a project memory (name, path, date, purpose, test artifact location) and index it in MEMORY.md.
