# Transcript Extraction Ladder

Ordered by reliability observed in practice (2026-07). Stop at the first rung that works, but rung 4 is the one that reliably succeeds — don't burn many turns on rungs 2–3.

## Rung 1 — WebFetch the watch page
`WebFetch` on the YouTube URL. Usually returns only footer/nav (YouTube is JS-rendered) — worth one try for non-YouTube hosts (blogs, docs, Loom) where it often just works.

## Rung 2 — Browser pane: title, description, chapters
Open the URL with `preview_start {url}`. Then:
- `get_page_text` → title, channel, view count, related videos.
- Press `k` (pause playback) before anything else.
- Expand the description: click `#expand` via `javascript_tool`, then read `#description-inline-expander` innerText → **description, links, chapter timestamps, license**. This alone often gives the full workflow outline.

Note the tabId quirk: `preview_start` may report tabId `seed`, and `main` may not exist — call `tabs_context` and use what's actually there.

## Rung 3 — Transcript panel / caption APIs (usually fail — timebox to ~3 attempts)
Known failure modes, so you don't re-discover them:
- Clicking "Show transcript" opens the panel but segments (`ytd-transcript-segment-renderer`) never render in the embedded browser.
- The caption track URL from `ytInitialPlayerResponse.captions...baseUrl` returns **200 with an empty body** (YouTube requires a proof-of-origin token now).
- Innertube `POST /youtubei/v1/get_transcript` returns 400 "Precondition check failed".
- Third-party transcript sites (youtubetotranscript.com, youtubetranscript.com) return 403 to WebFetch; notegpt.io returns marketing copy, not the transcript.

## Rung 4 — yt-dlp auto-subtitles (the reliable path)
```bash
pip install -q yt-dlp
cd <scratchpad>
yt-dlp --skip-download --write-auto-subs --sub-langs "en" --sub-format "vtt" -o "video" "<URL>"
```
Then convert VTT → clean text (dedupe consecutive lines — auto-subs repeat every line):
```python
import re
lines = open('video.en.vtt', encoding='utf-8').read().splitlines()
out, seen = [], None
for ln in lines:
    if '-->' in ln or ln.strip().isdigit() or ln.startswith(('WEBVTT','Kind:','Language:')):
        continue
    txt = re.sub(r'<[^>]+>', '', ln).strip()
    if txt and txt != seen:
        out.append(txt); seen = txt
open('transcript.txt','w',encoding='utf-8').write(' '.join(out))
```
Read the result with the Read tool. A 15-minute video ≈ 18k chars — fits in one read.

## Rung 5 — No captions at all
If yt-dlp finds no subs in any language: fall back to a video-analysis MCP tool if one is connected (e.g. Higgsfield `video_analysis_create`), or tell the user the video has no captions and ask them to summarize the key moments while you work from description + chapters.

## Non-YouTube sources
- Loom/Vimeo/Wistia: try Rung 1, then Rung 4 (yt-dlp supports most hosts).
- Course platforms behind login: do not scrape. Ask the user to export/paste what they own.
