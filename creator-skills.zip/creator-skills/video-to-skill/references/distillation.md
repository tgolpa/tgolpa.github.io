# Distillation: Transcript → Architecture

The transcript is raw ore. The skill is built from what it *implies*, not what it says. Work through these five extractions in order.

## 1. Workflow spine
Map chapters/timestamps to numbered steps. Verify against the transcript that each chapter is a real step and note which steps are one-time setup (connecting a tool) vs. the repeatable loop (the part worth encoding).

## 2. The creator's discovered abstraction
Somewhere in every good tutorial the creator compresses the problem: "it's not 40 unique databases, it's 10 patterns repeated and reskinned", "build it as a pattern-assembly engine, not a hardcoded template". **That sentence is the skill's architecture.** Hunt for it explicitly — words like "pattern", "system", "the trick is", "what I realized". If the video names N patterns but only lists 4, flesh out the rest from domain knowledge and label them as inferred.

## 3. Failure → fix moments
The most valuable content is where the creator's first attempt failed and they corrected: what the failure looked like, what the diagnosis was, what changed. These become *mandatory rules* in the skill (not suggestions), because they're the mistakes the skill will otherwise repeat. Tutorials that show "the real experience" of iteration are worth far more than polished happy paths.

## 4. What's sold vs. what's shown
List what the creator gates (the pack, the $X community, the done-for-you files) and confirm the *method* is fully shown. Usually the paid artifact is just the output of the taught method — which you can regenerate. If a critical step is genuinely only in the paid content, flag the gap and design around it or stop.

## 5. Environment deltas
List every tool/product named in the video, then check what actually exists here: exact MCP server and tool names (ToolSearch), current schemas, OS differences, model/feature changes since the video was published. The video is evidence of *what's possible*, never documentation of *how to call it*. Write reference files only from schemas you loaded yourself.

## Output of this phase
A one-page build brief: workflow spine, core abstraction, mandatory rules (from failures), verified tool inventory, and the smoke test you'll run. Show it to the user briefly if scope is ambiguous; otherwise proceed to authoring.
